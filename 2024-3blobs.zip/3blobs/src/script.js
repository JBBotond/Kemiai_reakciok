// const b1 = document.querySelector('.blob.a');
// const b2 = document.querySelector('.blob.b');
// const b3 = document.querySelector('.blob.c');

// animate stuff

